Make changes in the "Test" branch first and then apply it to the main branch
